#!/bin/bash

# rename English holder
LANG=C xdg-user-dirs-gtk-update

# install chromium-browser
sudo apt-get install chromium-browser

# install terminator
sudo apt-get install terminator

# ssh
sudo apt-get install openssh-server

# good tool gnome-tweaks
sudo apt-get install gnome-tweaks
